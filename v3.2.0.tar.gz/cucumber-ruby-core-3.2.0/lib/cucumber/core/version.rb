# frozen_string_literal: true
module Cucumber
  module Core
    class Version
      def self.to_s
        "3.2.0"
      end
    end
  end
end
